# NULEX - Task & Referral Earning Platform

## Overview

NULEX is a task-based earning platform where users complete tasks and refer others to earn money. The platform features a tiered package system (Knight at ₦4,500 and Elite at ₦9,000), dual balance tracking (task earnings vs affiliate/referral earnings), and an admin approval workflow for deposits and withdrawals.

Key features:
- User registration with referral tracking
- Package-based membership tiers requiring payment verification
- Task completion for earning rewards
- Referral commissions based on package tier
- Withdrawal system with minimum thresholds (₦1,000 for affiliate, ₦15,000 for tasks)
- Admin dashboard for approving deposits/withdrawals and managing tasks

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state caching and synchronization
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom blue/white theme using CSS variables
- **Forms**: React Hook Form with Zod validation
- **Animations**: Framer Motion for page transitions and micro-interactions

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ESM modules
- **API Pattern**: RESTful endpoints under `/api/*`
- **Authentication**: Passport.js with Local Strategy, express-session for session management
- **Session Storage**: PostgreSQL-backed sessions via connect-pg-simple
- **Build Tool**: esbuild for server bundling, Vite for client development and production builds

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL (connection via DATABASE_URL environment variable)
- **Schema Location**: `shared/schema.ts` contains all table definitions (users, tasks, withdrawals, deposits)
- **Migrations**: Drizzle Kit with `db:push` command for schema synchronization
- **Validation**: Drizzle-Zod generates Zod schemas from database tables for type-safe validation

### Key Design Patterns
- **Shared Types**: The `shared/` directory contains schema and route definitions used by both client and server, ensuring type consistency
- **Storage Abstraction**: `server/storage.ts` implements `IStorage` interface for all database operations
- **Protected Routes**: Frontend uses `ProtectedRoute` wrapper component that checks authentication state before rendering
- **Dual Balance System**: Users have separate `taskBalance` and `affiliateBalance` fields with different withdrawal minimums
- **Payment Verification Flow**: Users select a package, upload proof of payment (base64 encoded), and await admin approval before accessing the full dashboard

### User Flow States
1. **New User**: Registers with optional referrer, sees blocked dashboard with package selection
2. **Pending Payment**: User has selected package and uploaded proof, awaiting admin verification
3. **Verified User**: Full dashboard access with tasks, withdrawals, and referral features
4. **Admin User**: Additional admin panel for managing users, deposits, withdrawals, and tasks

## External Dependencies

### Database
- **PostgreSQL**: Primary database for all application data and session storage
- **Connection**: Configured via `DATABASE_URL` environment variable

### Third-Party Services
- **Payment Processing**: Manual bank transfer verification (no payment gateway integration)
  - Account: 9857574169, Bank: Paystack-Titan, Name: CHIPPERCASH/dorathy Hanson
  - Users upload payment proof images for admin verification

### Key NPM Packages
- `drizzle-orm` / `drizzle-kit`: Database ORM and migration tooling
- `passport` / `passport-local`: Authentication strategy
- `express-session` / `connect-pg-simple`: Session management with PostgreSQL backing
- `@tanstack/react-query`: Client-side data fetching and caching
- `zod`: Runtime type validation
- `framer-motion`: Animation library
- `react-hook-form`: Form state management