import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import { useUser } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

import AuthPage from "@/pages/auth";
import Dashboard from "@/pages/dashboard";
import TasksPage from "@/pages/tasks";
import WithdrawPage from "@/pages/withdraw";
import AdminPage from "@/pages/admin";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ component: Component, adminOnly = false }: { component: React.ComponentType, adminOnly?: boolean }) {
  const { data: user, isLoading } = useUser();

  if (isLoading) {
    return <div className="flex h-screen items-center justify-center"><Loader2 className="animate-spin text-blue-600" /></div>;
  }

  if (!user) {
    // Redirect logic handled inside AuthPage if user exists, but here we render AuthPage if no user
    // However, wouter doesn't have a direct Redirect component that replaces history easily in this version
    // So we just show AuthPage which handles its own redirect if user IS logged in
    return <AuthPage />;
  }
  
  if (adminOnly && !user.isAdmin) {
    return <div className="p-8 text-center">Access Denied</div>;
  }

  return (
    <Layout>
      <Component />
    </Layout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      
      <Route path="/">
        <ProtectedRoute component={Dashboard} />
      </Route>
      
      <Route path="/tasks">
        <ProtectedRoute component={TasksPage} />
      </Route>
      
      <Route path="/withdraw">
        <ProtectedRoute component={WithdrawPage} />
      </Route>
      
      <Route path="/admin">
        <ProtectedRoute component={AdminPage} adminOnly />
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
