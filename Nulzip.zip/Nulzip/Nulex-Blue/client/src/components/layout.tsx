import { Link, useLocation } from "wouter";
import { useUser, useLogout } from "@/hooks/use-auth";
import { 
  LayoutDashboard, 
  CheckSquare, 
  Wallet, 
  LogOut, 
  Menu, 
  X,
  ShieldAlert,
  Users
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { data: user } = useUser();
  const { mutate: logout } = useLogout();
  const [open, setOpen] = useState(false);

  const NavContent = () => (
    <div className="flex flex-col h-full">
      <div className="p-6 border-b border-border/50">
        <div className="flex items-center gap-3">
           {/* Static logo from implementation notes placeholder */}
           <img 
             src="https://i.ibb.co/gXJMKYR/C8-C8-E7-AB-4-F4-B-4303-8-A01-97-B088-E53-BEB.jpg" 
             alt="Nulex Logo" 
             className="w-10 h-10 rounded-lg object-cover shadow-sm"
           />
           <span className="font-display font-bold text-2xl text-blue-700">NULEX</span>
        </div>
      </div>
      
      <nav className="flex-1 p-4 space-y-2">
        <NavItem href="/" icon={<LayoutDashboard size={20} />} label="Dashboard" active={location === "/"} onClick={() => setOpen(false)} />
        
        {user?.paymentStatus === "verified" && (
          <>
            <NavItem href="/tasks" icon={<CheckSquare size={20} />} label="Tasks Hall" active={location === "/tasks"} onClick={() => setOpen(false)} />
            <NavItem href="/withdraw" icon={<Wallet size={20} />} label="Withdrawals" active={location === "/withdraw"} onClick={() => setOpen(false)} />
          </>
        )}
        
        {user?.isAdmin && (
           <div className="pt-4 mt-4 border-t border-border/50">
             <div className="px-4 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Admin</div>
             <NavItem href="/admin" icon={<ShieldAlert size={20} />} label="Admin Panel" active={location === "/admin"} onClick={() => setOpen(false)} />
           </div>
        )}
      </nav>
      
      <div className="p-4 border-t border-border/50">
        <div className="bg-blue-50 rounded-xl p-4 mb-4">
           <p className="text-sm font-medium text-blue-900">Signed in as</p>
           <p className="text-xs text-blue-600 truncate">{user?.username}</p>
        </div>
        <Button variant="outline" className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200" onClick={() => logout()}>
          <LogOut size={18} className="mr-2" />
          Sign Out
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-72 bg-white border-r border-border h-screen sticky top-0 z-30">
        <NavContent />
      </aside>

      {/* Mobile Nav */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-md border-b border-border z-40 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
           <img 
             src="https://i.ibb.co/gXJMKYR/C8-C8-E7-AB-4-F4-B-4303-8-A01-97-B088-E53-BEB.jpg" 
             alt="Nulex Logo" 
             className="w-8 h-8 rounded-md"
           />
           <span className="font-display font-bold text-xl text-blue-700">NULEX</span>
        </div>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu size={24} />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-72 border-r border-border">
            <NavContent />
          </SheetContent>
        </Sheet>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-auto pt-16 lg:pt-0">
        <div className="max-w-6xl mx-auto p-4 md:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}

function NavItem({ href, icon, label, active, onClick }: { href: string; icon: React.ReactNode; label: string; active?: boolean; onClick?: () => void }) {
  return (
    <Link href={href} className={cn(
      "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium text-sm group",
      active 
        ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20" 
        : "text-slate-600 hover:bg-blue-50 hover:text-blue-700"
    )} onClick={onClick}>
      <span className={active ? "text-white" : "text-slate-400 group-hover:text-blue-600"}>{icon}</span>
      {label}
    </Link>
  );
}

// Helper utility
import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
