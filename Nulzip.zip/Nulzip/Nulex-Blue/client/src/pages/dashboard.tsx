import { useUser } from "@/hooks/use-auth";
import { useDashboardStats } from "@/hooks/use-dashboard";
import { useCreateDeposit, useDeposits } from "@/hooks/use-transactions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  Trophy, 
  Users, 
  TrendingUp, 
  Lock, 
  CheckCircle2, 
  AlertCircle,
  CreditCard,
  Copy,
  Upload
} from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { motion } from "framer-motion";

export default function Dashboard() {
  const { data: user } = useUser();
  const { data: stats } = useDashboardStats();
  const { data: deposits } = useDeposits();
  const { toast } = useToast();

  const isVerified = user?.packageTier !== "none" && user?.paymentStatus === "verified";
  
  const copyReferralLink = () => {
    const link = `${window.location.origin}/auth?ref=${user?.username}`;
    navigator.clipboard.writeText(link);
    toast({ title: "Copied!", description: "Referral link copied to clipboard." });
  };

  if (!isVerified) {
    return <UnverifiedDashboard user={user} deposits={deposits} />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Welcome back, {user?.username}!</h1>
          <p className="text-slate-500">Your current package: <Badge className="ml-2 uppercase bg-blue-100 text-blue-700 hover:bg-blue-200">{user?.packageTier}</Badge></p>
        </div>
        <Button variant="outline" className="gap-2" onClick={copyReferralLink}>
          <Copy size={16} />
          Copy Referral Link
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatsCard 
          title="Task Balance" 
          value={`₦${user?.taskBalance.toLocaleString()}`} 
          icon={<Trophy className="text-yellow-500" />} 
          description="Earnings from tasks"
        />
        <StatsCard 
          title="Affiliate Balance" 
          value={`₦${user?.affiliateBalance.toLocaleString()}`} 
          icon={<TrendingUp className="text-green-500" />} 
          description="Referral bonuses"
        />
        <StatsCard 
          title="Total Referrals" 
          value={stats?.referralCount || 0} 
          icon={<Users className="text-blue-500" />} 
          description="Friends invited"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="text-lg font-bold mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-4">
             <Button className="h-20 flex-col gap-2 bg-gradient-to-br from-blue-500 to-blue-700" asChild>
                <a href="/tasks">
                  <CheckCircle2 size={24} />
                  Start Tasks
                </a>
             </Button>
             <Button className="h-20 flex-col gap-2 bg-slate-100 text-slate-900 hover:bg-slate-200 border border-slate-200 shadow-none" asChild>
                <a href="/withdraw">
                  <CreditCard size={24} />
                  Withdraw Funds
                </a>
             </Button>
          </div>
        </Card>

        <Card className="p-6">
           <h3 className="text-lg font-bold mb-4">Account Status</h3>
           <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-green-50 text-green-700 rounded-lg border border-green-100">
                 <span className="flex items-center gap-2 font-medium"><CheckCircle2 size={18} /> Account Verified</span>
                 <span className="text-sm">Active</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-blue-50 text-blue-700 rounded-lg border border-blue-100">
                 <span className="flex items-center gap-2 font-medium"><Users size={18} /> Referral Tier</span>
                 <span className="text-sm font-bold uppercase">{user?.packageTier}</span>
              </div>
           </div>
        </Card>
      </div>
    </div>
  );
}

function UnverifiedDashboard({ user, deposits }: { user: any, deposits: any[] | undefined }) {
  const pendingDeposit = deposits?.find(d => d.status === "pending");
  const rejectedDeposit = deposits?.find(d => d.status === "rejected"); // naive check, just shows last rejection
  const [selectedPackage, setSelectedPackage] = useState<"knight" | "elite">("knight");

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div className="text-center space-y-2">
        <h1 className="text-4xl font-display font-bold text-slate-900">Activate Your Account</h1>
        <p className="text-slate-500 text-lg">Choose a package to unlock earning opportunities</p>
      </div>

      {/* Welcome Bonus Teaser */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white p-6 rounded-2xl shadow-xl shadow-orange-500/20 flex items-center justify-between"
      >
         <div className="flex items-center gap-4">
            <div className="p-3 bg-white/20 rounded-full backdrop-blur">
               <Trophy size={32} />
            </div>
            <div>
               <h3 className="font-bold text-xl">₦1,000 Welcome Bonus</h3>
               <p className="text-orange-50 font-medium">Waiting for you upon activation!</p>
            </div>
         </div>
         <Lock className="opacity-50" size={32} />
      </motion.div>

      {pendingDeposit ? (
         <Alert className="bg-blue-50 border-blue-200 text-blue-800">
            <TrendingUp className="h-4 w-4" />
            <AlertTitle>Verification in Progress</AlertTitle>
            <AlertDescription>
               We received your payment proof for the <span className="font-bold uppercase">{pendingDeposit.packageTier}</span> package. 
               Please wait while an admin verifies your transaction. This usually takes 1-2 hours.
            </AlertDescription>
         </Alert>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Packages */}
          <PackageCard 
            name="Knight" 
            price="4,500" 
            features={["Earn per task", "Referral Bonus: ₦3,000", "Weekly Withdrawals"]} 
            active={selectedPackage === "knight"}
            onClick={() => setSelectedPackage("knight")}
          />
          <PackageCard 
            name="Elite" 
            price="7,500" 
            features={["Higher task earnings", "Referral Bonus: ₦5,000", "Daily Withdrawals", "Priority Support"]} 
            active={selectedPackage === "elite"}
            onClick={() => setSelectedPackage("elite")}
            recommended
          />
        </div>
      )}
      
      {!pendingDeposit && (
        <Card className="p-8 border-2 border-blue-100 shadow-xl shadow-blue-900/5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
               <h3 className="text-xl font-bold flex items-center gap-2">
                 <CreditCard className="text-blue-600" />
                 Payment Details
               </h3>
               <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 space-y-4">
                  <div>
                    <Label className="text-xs text-slate-500 uppercase tracking-wider">Bank Name</Label>
                    <p className="font-mono text-lg font-bold text-slate-900">Paystack-Titan</p>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500 uppercase tracking-wider">Account Number</Label>
                    <div className="flex items-center gap-2">
                       <p className="font-mono text-2xl font-bold text-blue-700 tracking-wider">9857574169</p>
                       <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => navigator.clipboard.writeText("9857574169")}>
                          <Copy size={14} />
                       </Button>
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500 uppercase tracking-wider">Account Name</Label>
                    <p className="font-mono text-lg font-bold text-slate-900">CHIPPERCASH/dorathy Hanson</p>
                  </div>
               </div>
               <p className="text-sm text-slate-500">
                 Transfer <span className="font-bold text-slate-900">₦{selectedPackage === 'knight' ? '4,500' : '7,500'}</span> to the account above, then upload your proof of payment.
               </p>
            </div>

            <div className="space-y-6">
               <h3 className="text-xl font-bold flex items-center gap-2">
                 <Upload className="text-blue-600" />
                 Confirm Payment
               </h3>
               <PaymentProofForm packageTier={selectedPackage} />
            </div>
          </div>
        </Card>
      )}

      {/* History of deposits if any */}
      {deposits && deposits.length > 0 && (
        <div className="pt-8 border-t border-slate-100">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Payment History</h3>
          <div className="space-y-3">
            {deposits.map((deposit) => (
              <div key={deposit.id} className="flex items-center justify-between p-4 bg-white rounded-xl border border-slate-100">
                <div className="flex items-center gap-3">
                   <div className={`w-2 h-2 rounded-full ${
                     deposit.status === 'verified' ? 'bg-green-500' : 
                     deposit.status === 'rejected' ? 'bg-red-500' : 'bg-yellow-500'
                   }`} />
                   <div>
                     <p className="font-medium text-slate-900">₦{deposit.amount.toLocaleString()} Deposit</p>
                     <p className="text-xs text-slate-500">{format(new Date(deposit.createdAt), 'MMM dd, yyyy HH:mm')}</p>
                   </div>
                </div>
                <Badge variant={deposit.status === 'verified' ? 'default' : 'outline'}>
                  {deposit.status}
                </Badge>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function PaymentProofForm({ packageTier }: { packageTier: string }) {
  const { mutate: createDeposit, isPending } = useCreateDeposit();
  const [base64Data, setBase64Data] = useState("");
  const { toast } = useToast();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setBase64Data(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!base64Data) {
      toast({ title: "File Required", description: "Please upload your payment proof image", variant: "destructive" });
      return;
    }
    
    createDeposit({
      amount: packageTier === 'knight' ? 4500 : 7500,
      packageTier: packageTier as 'knight' | 'elite',
      proofBase64: base64Data,
    }, {
      onSuccess: () => toast({ title: "Submitted", description: "Payment proof submitted for review." }),
      onError: (err) => toast({ title: "Error", description: err.message, variant: "destructive" })
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label>Proof Image (Receipt)</Label>
        <Input 
          type="file"
          accept="image/*"
          onChange={handleFileChange} 
          required 
          className="cursor-pointer"
        />
        <p className="text-xs text-slate-500">Upload a clear screenshot or photo of your payment receipt.</p>
      </div>
      {base64Data && (
        <div className="mt-2 p-2 border rounded-lg bg-slate-50">
          <img src={base64Data} alt="Proof preview" className="max-h-32 mx-auto rounded" />
        </div>
      )}
      <Button className="w-full" size="lg" disabled={isPending}>
        {isPending ? "Submitting..." : `I have sent ₦${packageTier === 'knight' ? '4,500' : '7,500'}`}
      </Button>
    </form>
  );
}

function PackageCard({ name, price, features, active, onClick, recommended }: any) {
  return (
    <div 
      onClick={onClick}
      className={`relative p-6 rounded-2xl border-2 transition-all cursor-pointer ${
        active 
          ? 'border-blue-600 bg-blue-50/50 shadow-lg scale-[1.02]' 
          : 'border-slate-100 bg-white hover:border-blue-200'
      }`}
    >
      {recommended && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-orange-500 to-red-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg shadow-orange-500/30">
          RECOMMENDED
        </div>
      )}
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="font-bold text-lg uppercase tracking-wide text-slate-700">{name}</h3>
          <p className="text-3xl font-bold text-slate-900 mt-1">₦{price}</p>
        </div>
        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${active ? 'border-blue-600' : 'border-slate-300'}`}>
           {active && <div className="w-3 h-3 rounded-full bg-blue-600" />}
        </div>
      </div>
      <ul className="space-y-3">
        {features.map((feature: string, i: number) => (
          <li key={i} className="flex items-center gap-2 text-sm text-slate-600">
             <CheckCircle2 size={16} className="text-green-500" />
             {feature}
          </li>
        ))}
      </ul>
    </div>
  );
}

function StatsCard({ title, value, icon, description }: any) {
  return (
    <Card className="p-6 flex flex-col justify-between">
       <div className="flex justify-between items-start mb-4">
         <div className="p-2 bg-slate-50 rounded-lg">{icon}</div>
         <Badge variant="secondary" className="bg-slate-50 text-slate-500 hover:bg-slate-100">
            {description}
         </Badge>
       </div>
       <div>
         <p className="text-slate-500 font-medium text-sm">{title}</p>
         <h2 className="text-3xl font-bold text-slate-900 mt-1">{value}</h2>
       </div>
    </Card>
  );
}
