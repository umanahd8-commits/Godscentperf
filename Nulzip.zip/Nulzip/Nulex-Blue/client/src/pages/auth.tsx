import { useState } from "react";
import { useLogin, useRegister, useUser } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { api } from "@shared/routes";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AuthPage() {
  const { data: user, isLoading: isUserLoading } = useUser();
  const [, setLocation] = useLocation();

  if (isUserLoading) return <div className="min-h-screen flex items-center justify-center bg-blue-50"><Loader2 className="animate-spin text-blue-600 w-8 h-8" /></div>;
  if (user) {
    setLocation("/");
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-indigo-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-white/95 backdrop-blur shadow-2xl rounded-2xl border-0 overflow-hidden">
        <div className="p-8 pb-0 flex flex-col items-center">
           <img 
             src="https://i.ibb.co/gXJMKYR/C8-C8-E7-AB-4-F4-B-4303-8-A01-97-B088-E53-BEB.jpg" 
             alt="Nulex Logo" 
             className="w-16 h-16 rounded-xl shadow-lg mb-4"
           />
           <h1 className="text-3xl font-display font-bold text-slate-900 text-center">NULEX</h1>
           <p className="text-slate-500 text-sm mt-1 mb-6 text-center">Earn by completing tasks & referring friends</p>
        </div>

        <Tabs defaultValue="login" className="w-full">
          <TabsList className="grid w-full grid-cols-2 px-8 bg-transparent">
            <TabsTrigger value="login" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-600 rounded-lg">Login</TabsTrigger>
            <TabsTrigger value="register" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-600 rounded-lg">Sign Up</TabsTrigger>
          </TabsList>
          
          <div className="p-8 pt-6">
            <TabsContent value="login">
              <LoginForm />
            </TabsContent>
            <TabsContent value="register">
              <RegisterForm />
            </TabsContent>
          </div>
        </Tabs>
      </Card>
    </div>
  );
}

function LoginForm() {
  const { mutate: login, isPending } = useLogin();
  const { toast } = useToast();
  
  const form = useForm({
    resolver: zodResolver(api.auth.login.input),
    defaultValues: { username: "", password: "" },
  });

  function onSubmit(data: z.infer<typeof api.auth.login.input>) {
    login(data, {
      onError: (err) => {
        toast({ title: "Login failed", description: err.message, variant: "destructive" });
      }
    });
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="username"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Username</FormLabel>
              <FormControl>
                <Input placeholder="Enter username" {...field} className="bg-slate-50" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Password</FormLabel>
              <FormControl>
                <Input type="password" placeholder="••••••••" {...field} className="bg-slate-50" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" className="w-full h-11 text-base bg-blue-600 hover:bg-blue-700 mt-2" disabled={isPending}>
          {isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Sign In"}
        </Button>
      </form>
    </Form>
  );
}

function RegisterForm() {
  const { mutate: register, isPending } = useRegister();
  const { toast } = useToast();
  const [params] = useLocation(); // To check for referrer if needed, though usually query params
  // Parse query string manually as wouter useLocation doesn't return query params
  const searchParams = new URLSearchParams(window.location.search);
  const referrerUsername = searchParams.get("ref") || "";

  const form = useForm({
    resolver: zodResolver(api.auth.register.input),
    defaultValues: { 
      username: "", 
      password: "", 
      email: "", 
      phone: "", 
      referrerUsername 
    },
  });

  function onSubmit(data: z.infer<typeof api.auth.register.input>) {
    register(data, {
      onError: (err) => {
        toast({ title: "Registration failed", description: err.message, variant: "destructive" });
      }
    });
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <FormField
            control={form.control}
            name="username"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Username</FormLabel>
                <FormControl>
                  <Input placeholder="Username" {...field} className="bg-slate-50" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Phone</FormLabel>
                <FormControl>
                  <Input placeholder="080..." {...field} className="bg-slate-50" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input placeholder="you@example.com" {...field} className="bg-slate-50" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Password</FormLabel>
              <FormControl>
                <Input type="password" placeholder="••••••••" {...field} className="bg-slate-50" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="referrerUsername"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Referrer (Optional)</FormLabel>
              <FormControl>
                <Input placeholder="Referrer username" {...field} className="bg-slate-50" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full h-11 text-base bg-blue-600 hover:bg-blue-700 mt-2" disabled={isPending}>
          {isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Create Account"}
        </Button>
      </form>
    </Form>
  );
}
