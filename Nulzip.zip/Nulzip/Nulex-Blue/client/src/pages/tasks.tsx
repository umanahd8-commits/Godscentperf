import { useTasks, useCompleteTask } from "@/hooks/use-tasks";
import { useUser } from "@/hooks/use-auth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, PlayCircle, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function TasksPage() {
  const { data: tasks, isLoading } = useTasks();
  const { data: user } = useUser();
  const { mutate: completeTask, isPending: isCompleting } = useCompleteTask();
  const { toast } = useToast();

  const handleTaskClick = (taskId: number, url: string | null, reward: number) => {
    if (!url) return;
    window.open(url, "_blank");
    
    completeTask(taskId, {
      onSuccess: () => {
        toast({ 
          title: "Task Completed", 
          description: `You've earned ₦${reward}!` 
        });
      },
      onError: (err: any) => {
        toast({ 
          title: "Error", 
          description: err.message,
          variant: "destructive"
        });
      }
    });
  };

  if (isLoading) return <div className="flex justify-center p-12"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Tasks Hall</h1>
          <p className="text-slate-500">Complete tasks to earn rewards immediately.</p>
        </div>
        <div className="bg-blue-50 px-4 py-2 rounded-lg border border-blue-100">
           <span className="text-sm text-blue-600 font-medium">Your Balance: </span>
           <span className="text-lg font-bold text-blue-800">₦{user?.taskBalance.toLocaleString()}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tasks?.map((task) => (
          <Card key={task.id} className="p-6 hover:shadow-lg transition-shadow border-slate-200">
            <div className="flex justify-between items-start mb-4">
              <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-200 border-0">
                TASK #{task.id}
              </Badge>
              <div className="text-right">
                <span className="block text-xl font-bold text-green-600">₦{task.reward}</span>
                <span className="text-xs text-slate-400">Reward</span>
              </div>
            </div>
            
            <h3 className="font-bold text-lg mb-2">{task.title}</h3>
            <p className="text-slate-500 text-sm mb-6 line-clamp-2">{task.description}</p>
            
            <Button 
              className="w-full gap-2" 
              onClick={() => handleTaskClick(task.id, task.url, task.reward)}
              disabled={isCompleting}
            >
              {isCompleting ? <Loader2 className="animate-spin" /> : <PlayCircle size={18} />}
              Start Task
            </Button>
          </Card>
        ))}

        {(!tasks || tasks.length === 0) && (
           <div className="col-span-full py-12 text-center text-slate-400">
              <div className="bg-slate-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 size={32} />
              </div>
              <p>No tasks available right now. Check back later!</p>
           </div>
        )}
      </div>
    </div>
  );
}
