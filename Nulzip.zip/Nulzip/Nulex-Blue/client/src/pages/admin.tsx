import { useAdminUsers, useApproveDeposit, useRejectDeposit, useApproveWithdrawal, useRejectWithdrawal, useDeposits, useWithdrawals } from "@/hooks/use-transactions";
import { useCreateTask as useCreateTaskMutation } from "@/hooks/use-tasks";
import { useUser } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2, CheckCircle2, XCircle, Link } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogTrigger, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { api } from "@shared/routes";

export default function AdminPage() {
  const { data: user } = useUser();
  
  if (!user?.isAdmin) return <div className="p-10 text-center text-red-500">Access Denied</div>;

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Admin Dashboard</h1>
      
      <Tabs defaultValue="deposits" className="w-full">
        <TabsList className="grid w-full grid-cols-4 lg:w-[600px]">
          <TabsTrigger value="deposits">Deposits</TabsTrigger>
          <TabsTrigger value="withdrawals">Withdrawals</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
        </TabsList>
        
        <div className="mt-6">
          <TabsContent value="deposits">
             <DepositsTable />
          </TabsContent>
          <TabsContent value="withdrawals">
             <WithdrawalsTable />
          </TabsContent>
          <TabsContent value="users">
             <UsersTable />
          </TabsContent>
          <TabsContent value="tasks">
             <CreateTaskForm />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}

function DepositsTable() {
  const { data: deposits, isLoading } = useDeposits();
  const { mutate: approve, isPending: isApproving } = useApproveDeposit();
  const { mutate: reject, isPending: isRejecting } = useRejectDeposit();
  const { toast } = useToast();

  if (isLoading) return <Loader2 className="animate-spin" />;

  const handleApprove = (id: number) => {
    approve(id, {
      onSuccess: () => toast({ title: "Approved", description: "Deposit approved successfully" })
    });
  };

  const handleReject = (id: number) => {
    reject(id, {
      onSuccess: () => toast({ title: "Rejected", description: "Deposit has been declined" })
    });
  };

  return (
    <Card>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>User ID</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Package</TableHead>
            <TableHead>Proof</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {deposits?.map((d) => (
            <TableRow key={d.id}>
              <TableCell>#{d.userId}</TableCell>
              <TableCell>₦{d.amount}</TableCell>
              <TableCell className="uppercase">{d.packageTier}</TableCell>
              <TableCell>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="link" className="text-blue-600 p-0 h-auto flex items-center gap-1">
                      View <Link size={12} />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-3xl">
                    <DialogHeader>
                      <DialogTitle>Payment Proof</DialogTitle>
                    </DialogHeader>
                    <div className="mt-4 flex justify-center bg-slate-100 rounded-lg p-4">
                      <img 
                        src={d.proofBase64} 
                        alt="Deposit proof" 
                        className="max-w-full max-h-[70vh] object-contain rounded-md"
                      />
                    </div>
                  </DialogContent>
                </Dialog>
              </TableCell>
              <TableCell><Badge>{d.status}</Badge></TableCell>
              <TableCell>
                {d.status === 'pending' && (
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="bg-green-600 hover:bg-green-700" 
                      onClick={() => handleApprove(d.id)} 
                      disabled={isApproving || isRejecting}
                    >
                      Approve
                    </Button>
                    <Button 
                      size="sm" 
                      variant="destructive" 
                      onClick={() => handleReject(d.id)} 
                      disabled={isApproving || isRejecting}
                    >
                      Decline
                    </Button>
                  </div>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Card>
  );
}

function WithdrawalsTable() {
  const { data: withdrawals, isLoading } = useWithdrawals();
  const { mutate: approve, isPending: isApproving } = useApproveWithdrawal();
  const { mutate: reject, isPending: isRejecting } = useRejectWithdrawal();
  const { toast } = useToast();

  if (isLoading) return <Loader2 className="animate-spin" />;
  
  const handleApprove = (id: number) => {
    approve(id, {
      onSuccess: () => toast({ title: "Approved", description: "Withdrawal approved" })
    });
  };

  const handleReject = (id: number) => {
    reject(id, {
      onSuccess: () => toast({ title: "Rejected", description: "Withdrawal rejected and balance refunded" })
    });
  };

  return (
    <Card>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>User ID</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Balance Type</TableHead>
            <TableHead>Bank Details</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {withdrawals?.map((w) => (
            <TableRow key={w.id}>
              <TableCell>#{w.userId}</TableCell>
              <TableCell>₦{w.amount}</TableCell>
              <TableCell className="uppercase">{w.balanceType}</TableCell>
              <TableCell>{w.bankDetails}</TableCell>
              <TableCell><Badge>{w.status}</Badge></TableCell>
              <TableCell>
                {w.status === 'pending' && (
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="bg-green-600 hover:bg-green-700"
                      onClick={() => handleApprove(w.id)} 
                      disabled={isApproving || isRejecting}
                    >
                      Approve
                    </Button>
                    <Button 
                      size="sm" 
                      variant="destructive"
                      onClick={() => handleReject(w.id)} 
                      disabled={isApproving || isRejecting}
                    >
                      Reject
                    </Button>
                  </div>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Card>
  );
}

function UsersTable() {
  const { data: users, isLoading } = useAdminUsers();

  if (isLoading) return <Loader2 className="animate-spin" />;

  return (
    <Card>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            <TableHead>Username</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Package</TableHead>
            <TableHead>Referrals</TableHead>
            <TableHead>Balance</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users?.map((u: any) => (
            <TableRow key={u.id}>
              <TableCell>#{u.id}</TableCell>
              <TableCell className="font-medium">{u.username}</TableCell>
              <TableCell>{u.email}</TableCell>
              <TableCell><Badge variant="outline">{u.packageTier}</Badge></TableCell>
              <TableCell>{u.referralCount || 0}</TableCell>
              <TableCell>Task: ₦{u.taskBalance} / Aff: ₦{u.affiliateBalance}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Card>
  );
}

function CreateTaskForm() {
  const { mutate: createTask, isPending } = useCreateTaskMutation();
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [reward, setReward] = useState(100);
  const [url, setUrl] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createTask({ title, description: desc, reward, url }, {
      onSuccess: () => {
        toast({ title: "Created", description: "Task created successfully" });
        setTitle(""); setDesc(""); setReward(100); setUrl("");
      }
    });
  };

  return (
    <Card className="p-6 max-w-xl">
       <h3 className="text-lg font-bold mb-4">Add New Task</h3>
       <form onSubmit={handleSubmit} className="space-y-4">
         <div className="space-y-2">
           <Label>Title</Label>
           <Input value={title} onChange={e => setTitle(e.target.value)} required />
         </div>
         <div className="space-y-2">
           <Label>Description</Label>
           <Textarea value={desc} onChange={e => setDesc(e.target.value)} required />
         </div>
         <div className="grid grid-cols-2 gap-4">
           <div className="space-y-2">
             <Label>Reward (₦)</Label>
             <Input type="number" value={reward} onChange={e => setReward(Number(e.target.value))} required />
           </div>
           <div className="space-y-2">
             <Label>Task URL</Label>
             <Input value={url} onChange={e => setUrl(e.target.value)} placeholder="https://..." />
           </div>
         </div>
         <Button disabled={isPending}>Create Task</Button>
       </form>
    </Card>
  );
}
