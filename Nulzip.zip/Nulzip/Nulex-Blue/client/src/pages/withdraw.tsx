import { useUser } from "@/hooks/use-auth";
import { useWithdrawals, useCreateWithdrawal } from "@/hooks/use-transactions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { api } from "@shared/routes";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Loader2, AlertCircle, History } from "lucide-react";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function WithdrawPage() {
  const { data: user } = useUser();
  const { data: withdrawals } = useWithdrawals();
  const { mutate: withdraw, isPending } = useCreateWithdrawal();
  const { toast } = useToast();

  const form = useForm({
    resolver: zodResolver(api.withdrawals.create.input),
    defaultValues: {
      amount: 0,
      balanceType: "task" as "task" | "affiliate",
      bankDetails: "",
    },
  });

  const balanceType = form.watch("balanceType");
  const currentBalance = balanceType === "task" ? user?.taskBalance : user?.affiliateBalance;
  const minWithdrawal = balanceType === "task" ? 15000 : 1000;

  function onSubmit(data: any) {
    if ((currentBalance || 0) < data.amount) {
      form.setError("amount", { message: "Insufficient balance" });
      return;
    }
    if (data.amount < minWithdrawal) {
      form.setError("amount", { message: `Minimum withdrawal is ₦${minWithdrawal}` });
      return;
    }

    withdraw(data, {
      onSuccess: () => {
        toast({ title: "Request Submitted", description: "Your withdrawal request has been sent for approval." });
        form.reset();
      },
      onError: (err) => {
        toast({ title: "Failed", description: err.message, variant: "destructive" });
      }
    });
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Withdraw Funds</h1>
        <p className="text-slate-500">Request a payout to your bank account.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6">
             <Form {...form}>
               <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                 <FormField
                    control={form.control}
                    name="balanceType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Source Account</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="h-12">
                              <SelectValue placeholder="Select balance" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="task">
                               Task Balance (Available: ₦{user?.taskBalance?.toLocaleString() || '0'})
                            </SelectItem>
                            <SelectItem value="affiliate">
                               Affiliate Balance (Available: ₦{user?.affiliateBalance?.toLocaleString() || '0'})
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                 />

                 <div className="p-4 bg-slate-50 rounded-lg border border-slate-100 text-sm text-slate-600 flex gap-2">
                    <AlertCircle className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                    <p>Minimum withdrawal for {balanceType === 'task' ? 'Tasks' : 'Affiliates'} is <strong>₦{minWithdrawal.toLocaleString()}</strong>.</p>
                 </div>

                 <FormField
                    control={form.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Amount (₦)</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} onChange={e => field.onChange(Number(e.target.value))} className="h-12 text-lg" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                 />

                 <FormField
                    control={form.control}
                    name="bankDetails"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Bank Details</FormLabel>
                        <FormControl>
                          <Input placeholder="Bank Name - Account Number - Account Name" {...field} className="h-12" />
                        </FormControl>
                        <p className="text-xs text-slate-500">Format: Bank Name - Acct Number - Acct Name</p>
                        <FormMessage />
                      </FormItem>
                    )}
                 />

                 <Button type="submit" size="lg" className="w-full" disabled={isPending}>
                   {isPending ? <Loader2 className="animate-spin mr-2" /> : "Submit Withdrawal Request"}
                 </Button>
               </form>
             </Form>
          </Card>
        </div>

        <div>
          <Card className="h-full flex flex-col">
            <div className="p-6 border-b border-border">
               <h3 className="font-bold flex items-center gap-2">
                 <History size={18} /> Withdrawal History
               </h3>
            </div>
            <div className="flex-1 overflow-auto p-4 space-y-3 max-h-[500px]">
              {withdrawals?.map((w) => (
                <div key={w.id} className="flex flex-col p-3 rounded-lg border border-slate-100 bg-slate-50/50">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-slate-900">₦{w.amount.toLocaleString()}</span>
                    <Badge variant={w.status === 'approved' ? 'default' : w.status === 'rejected' ? 'destructive' : 'secondary'} className="text-xs no-default-hover-elevate no-default-active-elevate">
                      {w.status}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center text-xs text-slate-500">
                    <span className="uppercase">{w.balanceType}</span>
                    <span>{w.createdAt ? format(new Date(w.createdAt), 'MMM dd') : 'N/A'}</span>
                  </div>
                </div>
              ))}
              {(!withdrawals || withdrawals.length === 0) && (
                <div className="text-center py-8 text-slate-400 text-sm">No history yet</div>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
