## Packages
framer-motion | For smooth page transitions and micro-interactions
recharts | For visualizing earning history on the dashboard
lucide-react | For beautiful icons (already in base, but emphasizing use)

## Notes
Theme: Blue (#0066cc) and White as requested.
Fonts: 'Inter' for UI, maybe a display font for headers.
Dashboard Logic: Strict separation between 'unverified/new' users and 'active' users based on packageTier/paymentStatus.
