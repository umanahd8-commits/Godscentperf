import { db } from "./db";
import {
  users, tasks, withdrawals, deposits,
  type User, type InsertUser, type Task, type Withdrawal, type Deposit,
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";

type InsertTask = typeof tasks.$inferInsert;
type InsertWithdrawal = typeof withdrawals.$inferInsert;
type InsertDeposit = typeof deposits.$inferInsert;

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;
  getAllUsers(): Promise<User[]>;

  // Tasks
  getTasks(): Promise<Task[]>;
  createTask(task: { title: string; description: string; reward: number; url?: string }): Promise<Task>;

  // Withdrawals
  getWithdrawals(userId?: number): Promise<Withdrawal[]>;
  createWithdrawal(withdrawal: { userId: number; amount: number; balanceType: "task" | "affiliate"; bankDetails: string }): Promise<Withdrawal>;
  updateWithdrawalStatus(id: number, status: "approved" | "rejected"): Promise<Withdrawal>;

  // Deposits
  getDeposits(userId?: number): Promise<Deposit[]>;
  createDeposit(deposit: { userId: number; amount: number; packageTier: "none" | "knight" | "elite"; proofBase64: string }): Promise<Deposit>;
  updateDepositStatus(id: number, status: "verified" | "rejected"): Promise<Deposit>;
  getDeposit(id: number): Promise<Deposit | undefined>;

  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      conString: process.env.DATABASE_URL,
      createTableIfMissing: true,
    });
  }
  // User
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  // Tasks
  async getTasks(): Promise<Task[]> {
    return await db.select().from(tasks).orderBy(desc(tasks.createdAt));
  }

  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }

  // Withdrawals
  async getWithdrawals(userId?: number): Promise<Withdrawal[]> {
    if (userId) {
      return await db.select().from(withdrawals).where(eq(withdrawals.userId, userId)).orderBy(desc(withdrawals.createdAt));
    }
    return await db.select().from(withdrawals).orderBy(desc(withdrawals.createdAt));
  }

  async createWithdrawal(withdrawal: InsertWithdrawal): Promise<Withdrawal> {
    const [newWithdrawal] = await db.insert(withdrawals).values(withdrawal).returning();
    return newWithdrawal;
  }

  async updateWithdrawalStatus(id: number, status: "approved" | "rejected"): Promise<Withdrawal> {
    const [updated] = await db.update(withdrawals).set({ status }).where(eq(withdrawals.id, id)).returning();
    return updated;
  }

  // Deposits
  async getDeposits(userId?: number): Promise<Deposit[]> {
    if (userId) {
      return await db.select().from(deposits).where(eq(deposits.userId, userId)).orderBy(desc(deposits.createdAt));
    }
    return await db.select().from(deposits).orderBy(desc(deposits.createdAt));
  }

  async createDeposit(deposit: InsertDeposit): Promise<Deposit> {
    const [newDeposit] = await db.insert(deposits).values(deposit).returning();
    return newDeposit;
  }

  async getDeposit(id: number): Promise<Deposit | undefined> {
     const [deposit] = await db.select().from(deposits).where(eq(deposits.id, id));
     return deposit;
  }

  async updateDepositStatus(id: number, status: "verified" | "rejected"): Promise<Deposit> {
    // Note: status in schema is "verified" but pgEnum might be "verified"
    const [updated] = await db.update(deposits).set({ status }).where(eq(deposits.id, id)).returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
