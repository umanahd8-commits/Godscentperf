import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { insertUserSchema } from "@shared/schema";

declare global {
  namespace Express {
    interface User {
      id: number;
      username: string;
      isAdmin: boolean;
    }
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth Setup
  app.use(
    session({
      secret: "nulex-secret-key", // In production use env var
      resave: false,
      saveUninitialized: false,
      cookie: { maxAge: 24 * 60 * 60 * 1000 } // 1 day
    })
  );
  
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || user.password !== password) { // In production use bcrypt
          return done(null, false);
        }
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    })
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // API Routes
  
  // Auth
  app.post(api.auth.register.path, async (req, res) => {
    try {
      // Handle referrer logic
      const input = req.body;
      const { referrerUsername, ...userData } = input;
      
      let referrerId: number | undefined;
      if (referrerUsername) {
        const referrer = await storage.getUserByUsername(referrerUsername);
        if (referrer) referrerId = referrer.id;
      }

      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Add default balance logic: 1000 welcome bonus to affiliate balance? 
      // Requirement: "welcome bonus of 1000naira... The welcome bonus will be in the affiliate balance"
      // But only active if package is purchased? 
      // "users cannot withdraw the welcome bonus without purchasing a package"
      // So we can give it now, but withdrawal logic checks package.
      
      const user = await storage.createUser({
        ...userData,
        referrerId,
        affiliateBalance: 1000, 
      });

      req.login(user, (err) => {
        if (err) throw err;
        res.status(201).json(user);
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
         res.status(400).json({ message: err.errors[0].message });
      } else {
         res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.post(api.auth.login.path, passport.authenticate("local"), (req, res) => {
    res.json(req.user);
  });

  app.post(api.auth.logout.path, (req, res) => {
    req.logout((err) => {
      if (err) return res.status(500).send("Logout failed");
      res.json({ message: "Logged out" });
    });
  });

  app.get(api.auth.me.path, (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send({ message: "Not authenticated" });
    res.json(req.user);
  });

  // Dashboard Stats
  app.get(api.dashboard.stats.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send({ message: "Not authenticated" });
    
    // Calculate simple stats
    // We could add a 'referralCount' to the user object or query it.
    // Since we don't have a direct query in storage for count, we'll implement getAllUsers or similar to count.
    // For efficiency, we should probably add getReferrals(userId) to storage.
    // For now, let's just return placeholders or what we have.
    const user = await storage.getUser(req.user!.id);
    if (!user) return res.status(404).send("User not found");

    // In a real app we'd do a count query. 
    // Let's assume user.affiliateBalance tracks total earnings for now + welcome bonus.
    
    res.json({
      referralCount: 0, // Placeholder, ideally implement storage.getReferralCount(id)
      totalEarnings: user.affiliateBalance + user.taskBalance
    });
  });

  // Tasks
  app.get(api.tasks.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send({ message: "Not authenticated" });
    const tasks = await storage.getTasks();
    res.json(tasks);
  });

  app.post(api.tasks.complete.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send({ message: "Not authenticated" });
    const taskId = Number(req.params.id);
    const tasks_list = await storage.getTasks();
    const task = tasks_list.find(t => t.id === taskId);
    
    if (!task) return res.status(404).send({ message: "Task not found" });

    const user = await storage.getUser(req.user!.id);
    if (!user) return res.status(404).send("User not found");

    await storage.updateUser(user.id, {
      taskBalance: user.taskBalance + task.reward
    });

    res.json({ message: "Task completed", reward: task.reward });
  });

  app.post(api.tasks.create.path, async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) return res.status(403).send({ message: "Forbidden" });
    const task = await storage.createTask(req.body);
    res.status(201).json(task);
  });

  // Withdrawals
  app.get(api.withdrawals.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send({ message: "Not authenticated" });
    const withdrawals = await storage.getWithdrawals(req.user!.id);
    res.json(withdrawals);
  });

  app.post(api.withdrawals.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send({ message: "Not authenticated" });
    const user = await storage.getUser(req.user!.id);
    if (!user) return res.status(404).send("User not found");

    const { amount, balanceType, bankDetails } = req.body;

    // Checks
    if (balanceType === 'affiliate' && amount < 1000) return res.status(400).send({ message: "Min affiliate withdrawal is 1000" });
    if (balanceType === 'task' && amount < 15000) return res.status(400).send({ message: "Min task withdrawal is 15000" });

    // Check balance
    if (balanceType === 'affiliate' && user.affiliateBalance < amount) return res.status(400).send({ message: "Insufficient affiliate balance" });
    if (balanceType === 'task' && user.taskBalance < amount) return res.status(400).send({ message: "Insufficient task balance" });

    // Deduct balance
    const update = balanceType === 'affiliate' 
      ? { affiliateBalance: user.affiliateBalance - amount }
      : { taskBalance: user.taskBalance - amount };
    
    await storage.updateUser(user.id, update);

    const withdrawal = await storage.createWithdrawal({
      userId: user.id,
      amount,
      balanceType,
      bankDetails: bankDetails,
    });
    
    res.status(201).json(withdrawal);
  });

  app.post(api.withdrawals.approve.path, async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) return res.status(403).send({ message: "Forbidden" });
    const withdrawal = await storage.updateWithdrawalStatus(Number(req.params.id), "approved");
    res.json(withdrawal);
  });

  app.post(api.withdrawals.reject.path, async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) return res.status(403).send({ message: "Forbidden" });
    
    const withdrawalId = Number(req.params.id);
    const withdrawal = await storage.getWithdrawals().then(ws => ws.find(w => w.id === withdrawalId));
    
    if (!withdrawal) return res.status(404).send({ message: "Withdrawal not found" });
    if (withdrawal.status !== 'pending') return res.status(400).send({ message: "Withdrawal already processed" });

    // Refund the user balance
    const user = await storage.getUser(withdrawal.userId);
    if (user) {
      const update = withdrawal.balanceType === 'affiliate'
        ? { affiliateBalance: user.affiliateBalance + withdrawal.amount }
        : { taskBalance: user.taskBalance + withdrawal.amount };
      await storage.updateUser(user.id, update);
    }

    const updatedWithdrawal = await storage.updateWithdrawalStatus(withdrawalId, "rejected");
    res.json(updatedWithdrawal);
  });

  // Deposits (Package Purchase)
  app.get(api.deposits.list.path, async (req, res) => {
     if (!req.isAuthenticated()) return res.status(401).send({ message: "Not authenticated" });
     // Admins see all? Or users see theirs? 
     // For now, let's assume admins check this endpoint or we filter.
     if (req.user!.isAdmin) {
       const deposits = await storage.getDeposits();
       res.json(deposits);
     } else {
       const deposits = await storage.getDeposits(req.user!.id);
       res.json(deposits);
     }
  });

  app.post(api.deposits.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send({ message: "Not authenticated" });
    const deposit = await storage.createDeposit({ ...req.body, userId: req.user!.id });
    res.status(201).json(deposit);
  });

  app.post(api.deposits.approve.path, async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) return res.status(403).send({ message: "Forbidden" });
    
    const depositId = Number(req.params.id);
    const deposit = await storage.getDeposit(depositId);
    if (!deposit) return res.status(404).send({ message: "Deposit not found" });

    const updatedDeposit = await storage.updateDepositStatus(depositId, "verified");
    
    // Activate User Package
    const user = await storage.getUser(deposit.userId);
    if (user) {
      await storage.updateUser(user.id, { 
        packageTier: deposit.packageTier, 
        paymentStatus: "verified" 
      });

      // Apply Referral Bonus
      if (user.referrerId) {
        const referrer = await storage.getUser(user.referrerId);
        if (referrer && referrer.packageTier !== 'none') {
           // Valid referrer with package
           let bonus = 0;
           if (referrer.packageTier === 'knight') {
             bonus = 1500; // Strict 1500 for Knight
           } else if (referrer.packageTier === 'elite') {
             if (deposit.packageTier === 'knight') bonus = 1500;
             if (deposit.packageTier === 'elite') bonus = 3500;
           }

           if (bonus > 0) {
             await storage.updateUser(referrer.id, {
               affiliateBalance: referrer.affiliateBalance + bonus
             });
           }
        }
      }
    }

    res.json(updatedDeposit);
  });

  app.post(api.deposits.reject.path, async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) return res.status(403).send({ message: "Forbidden" });
    const depositId = Number(req.params.id);
    const updatedDeposit = await storage.updateDepositStatus(depositId, "rejected");
    res.json(updatedDeposit);
  });
  
  // Admin
  app.get(api.admin.users.path, async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) return res.status(403).send({ message: "Forbidden" });
    const users = await storage.getAllUsers();
    res.json(users);
  });

  return httpServer;
}
