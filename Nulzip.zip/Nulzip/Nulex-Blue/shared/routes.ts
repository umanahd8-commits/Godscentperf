import { z } from 'zod';
import { insertUserSchema, insertTaskSchema, insertWithdrawalSchema, insertDepositSchema, users, tasks, withdrawals, deposits } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    register: {
      method: 'POST' as const,
      path: '/api/auth/register',
      input: insertUserSchema.extend({ referrerUsername: z.string().optional() }),
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    login: {
      method: 'POST' as const,
      path: '/api/auth/login',
      input: z.object({ username: z.string(), password: z.string() }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/auth/logout',
      responses: {
        200: z.object({ message: z.string() }),
      },
    },
    me: {
      method: 'GET' as const,
      path: '/api/user',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
  },
  dashboard: {
    stats: {
      method: 'GET' as const,
      path: '/api/dashboard/stats',
      responses: {
        200: z.object({
          referralCount: z.number(),
          totalEarnings: z.number(),
        }),
      },
    },
  },
  tasks: {
    list: {
      method: 'GET' as const,
      path: '/api/tasks',
      responses: {
        200: z.array(z.custom<typeof tasks.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/tasks',
      input: insertTaskSchema,
      responses: {
        201: z.custom<typeof tasks.$inferSelect>(),
        403: errorSchemas.unauthorized,
      },
    },
    complete: {
      method: 'POST' as const,
      path: '/api/tasks/:id/complete',
      responses: {
        200: z.object({ message: z.string(), reward: z.number() }),
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
  },
  withdrawals: {
    list: {
      method: 'GET' as const,
      path: '/api/withdrawals',
      responses: {
        200: z.array(z.custom<typeof withdrawals.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/withdrawals',
      input: insertWithdrawalSchema,
      responses: {
        201: z.custom<typeof withdrawals.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    approve: {
      method: 'POST' as const,
      path: '/api/withdrawals/:id/approve',
      responses: {
        200: z.custom<typeof withdrawals.$inferSelect>(),
        403: errorSchemas.unauthorized,
      },
    },
    reject: {
      method: 'POST' as const,
      path: '/api/withdrawals/:id/reject',
      responses: {
        200: z.custom<typeof withdrawals.$inferSelect>(),
        403: errorSchemas.unauthorized,
      },
    },
  },
  deposits: {
    list: {
      method: 'GET' as const,
      path: '/api/deposits',
      responses: {
        200: z.array(z.custom<typeof deposits.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/deposits',
      input: insertDepositSchema,
      responses: {
        201: z.custom<typeof deposits.$inferSelect>(),
      },
    },
    approve: {
      method: 'POST' as const,
      path: '/api/deposits/:id/approve',
      responses: {
        200: z.custom<typeof deposits.$inferSelect>(),
        403: errorSchemas.unauthorized,
      },
    },
    reject: {
      method: 'POST' as const,
      path: '/api/deposits/:id/reject',
      responses: {
        200: z.custom<typeof deposits.$inferSelect>(),
        403: errorSchemas.unauthorized,
      },
    },
  },
  admin: {
    users: {
      method: 'GET' as const,
      path: '/api/admin/users',
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
        403: errorSchemas.unauthorized,
      },
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
