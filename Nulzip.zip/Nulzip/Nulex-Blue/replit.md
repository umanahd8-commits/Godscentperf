# NULEX - Task & Referral Earning Platform

## Overview

NULEX is a task-based earning platform where users complete tasks and refer others to earn money. The platform features a tiered package system (Knight at ₦4,500 and Elite at ₦9,000), dual balance tracking (task earnings and affiliate earnings), and an admin panel for managing users, tasks, deposits, and withdrawals.

Key features:
- User registration with referral tracking
- Package-based membership tiers requiring payment verification
- Task completion for earning rewards
- Referral commissions based on package tier
- Withdrawal system with minimum thresholds (₦1,000 for affiliate, ₦15,000 for tasks)
- Admin dashboard for approving deposits/withdrawals and managing tasks

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom blue/white theme, CSS variables for theming
- **Forms**: React Hook Form with Zod validation
- **Animations**: Framer Motion for transitions

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ESM modules
- **API Pattern**: RESTful endpoints under `/api/*`
- **Authentication**: Passport.js with Local Strategy, express-session for session management
- **Build Tool**: esbuild for server bundling, Vite for client

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` - contains users, tasks, withdrawals, deposits tables
- **Migrations**: Drizzle Kit with `db:push` command
- **Validation**: Drizzle-Zod for generating Zod schemas from database tables

### Key Design Patterns
- **Shared Types**: The `shared/` directory contains schema and route definitions used by both client and server
- **Storage Abstraction**: `server/storage.ts` implements `IStorage` interface for database operations
- **Protected Routes**: Frontend uses `ProtectedRoute` wrapper component checking auth state
- **Dual Balance System**: Users have separate `taskBalance` and `affiliateBalance` fields
- **Payment Verification Flow**: Users select a package, upload proof of payment, await admin approval before accessing full dashboard

### User Flow States
1. **Unverified**: New users see blocked dashboard with package selection
2. **Pending**: After submitting payment proof, awaiting admin verification
3. **Verified**: Full dashboard access with tasks, withdrawals, referral features

## External Dependencies

### Database
- **PostgreSQL**: Primary database, connection via `DATABASE_URL` environment variable
- **connect-pg-simple**: Session storage in PostgreSQL

### Third-Party Services
- **Payment**: Manual bank transfer simulation (Paystack-Titan account details displayed to user)
- **Image Hosting**: Payment proofs stored as base64 in database

### Key NPM Packages
- `drizzle-orm` / `drizzle-kit`: Database ORM and migrations
- `express-session` / `passport` / `passport-local`: Authentication
- `@tanstack/react-query`: Client-side data fetching and caching
- `zod`: Runtime validation for API inputs/outputs
- `date-fns`: Date formatting utilities
- `framer-motion`: Animation library
- `recharts`: Dashboard charts and visualizations

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string